# Technical design
## Architecture
```mermaid
flowchart TD
 A[Assessment form] --> B[Rule-based scorer]
 B --> C[Skill gap priorities]
 C --> D[Weekly plan]
 D --> E[Completion and tutor notes]
 E --> F[Browser localStorage]
 F --> G[Progress view and JSON export]
```
## Data flow
The form collects a learner alias and six selected answers. Two questions per skill award 50 percentage points per correct answer. Scores below 75 are flagged for support. The weakest skills are ordered first and cycled over four sessions; when no gaps are flagged, all skills receive extension practice. Educators interpret and review the output.
## Record schema
`{name, scores:{Reading, English, Numeracy}, date, done:[sessionIndices], notes}`. Records are serialized under localStorage key `learnbridge-v1`. A storage failure leaves the current records in memory and displays a warning.
## Boundary
Single-file frontend with embedded questions and activities. No backend, network calls, paid services or AI. Hosted access needs a static server; local desktop use needs only a browser. No service worker or guaranteed hosted offline cache.
## Interface
Overview, Assessment, Learning plan, Progress & handover. Dynamic user text is escaped before HTML rendering. There are no production access controls; aliases and synthetic records should be used for demo purposes.
## Future evaluation
Use a larger validated question bank and alternate reassessment forms. Measure planning time and learning changes in a consent-based pilot before claiming effectiveness.
