# Test cases
Automated: `node tests.js`.

| Case | Expected |
|---|---|
| All correct | All skills 100%; no priority gaps |
| All wrong | All skills 0% |
| Mixed answers | Reading 50%, English 50%, Numeracy 100% |
| Different gaps | Weakest skill first |
| Threshold 75 / 74 | 75 is not flagged; 74 is flagged |
| All skills mastered | No priority gaps |

Manual browser checks (provided for reviewers; not claimed as executed): complete a quiz, mark and undo a session, save and reload a handover note, export JSON, repeat an alias for history, use a narrow mobile viewport, use Tamil prompts, and print a plan. Validate no personal student data is used.
