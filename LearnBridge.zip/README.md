# LearnBridge
A working Education & Skill Development prototype for identifying foundational learning gaps and helping teachers or NGO volunteers plan focused support.

## Run
Download the repository and open `index.html` in a modern desktop browser. No installation, build command, environment variables, API keys or backend are required. For hosting, serve this directory on any static web server, including GitHub Pages. iOS Files previews may not execute JavaScript; use the hosted page in Safari for the interactive demo.

## Demo in 90 seconds
1. Overview starts with one clearly labeled fictional learner.
2. Choose Assessment and enter a fictional learner alias.
3. Select English or Tamil + English instructions, then answer all six questions.
4. Submit to calculate Reading, English and Numeracy scores.
5. Review the four-session plan; mark a session complete.
6. Open Progress & handover, save a tutor note and export JSON.
7. Retake the assessment with the same alias to see assessment history.

## Stack and implementation
HTML, CSS, vanilla JavaScript and browser localStorage. This is the implemented prototype stack, replacing the initially proposed React/Python/SQLite stack. Rule-based scoring, not AI. No external dependencies. Assessment and stored activities operate offline once the file is locally available; this is not an installable PWA and a hosted page is not guaranteed to reopen offline.

## Features
Responsive interface; bilingual question prompts; gap identification; four-session plan; educator handover; local persistence; JSON export; printable plan. English answer options and activities remain English in this version.

## Tests
With Node.js installed, run `node tests.js`. Tests check correct/wrong/mixed scoring, threshold behavior and priority ordering. Manual browser checks: required answers block incomplete submission; blank learner alias is rejected; completing/undoing a session updates progress; saved notes survive reload when storage is permitted; exported JSON is readable. See TEST_CASES.md.

## Sample data
`sample-data.json` is synthetic. The same fictional record is embedded in the page so no fetch or server is required.

## Limits and next steps
This six-question screening is not a validated assessment. Repeated questions may inflate reassessment scores. Educators should review suggested activities. Data is device/browser-local; no authentication, cross-device synchronization, production child-data controls, or proven impact claims. Future work: validate question banks, add full Tamil activities and offline PWA caching, and pilot with consenting educators. Avoid real student personal data during demonstrations.

## Impact and sustainability
Pilot metrics: reassessment performance, completed sessions and teacher planning time. Reusable educator-reviewed content and school/NGO partnerships are the proposed sustainability model; no partnerships or measured outcomes are claimed.

## License
MIT; see LICENSE.
